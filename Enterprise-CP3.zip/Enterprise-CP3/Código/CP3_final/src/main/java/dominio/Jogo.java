package dominio;


import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "tab_jogo_CP3")
public class Jogo {
	//@EmbeddedId	
	//private JogoId codigo;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long codigo;
	
	@Column(length = 60, nullable = false)
	private String desenvolvedora;
	
	@Column(length = 60, nullable = false)
	private String nome;
	
	@Column(name = "ano_Lancamento", nullable = false)
	private Integer anoLancamento;
	
	@Column(name = "nota", nullable = false)
	private Integer nota;
	
	@Column(precision = 10, scale = 2, nullable = true)
	private BigDecimal valor;
	
	@Column(name = "tipo_jogo", nullable = false)
	@Enumerated(EnumType.STRING) // EnumType.ORDINAL (insere n�mero ao inv�s da string)
	private TipoJogo tipoJogo;
	
	@Temporal(TemporalType.DATE)
    @Column(name = "data_cadastro", nullable = true)
    private Calendar dataCadastro;
	
	
	@Lob
	private String especificacoes;
	@Lob
	private byte[] foto;
	
	@Transient
	private boolean vendas;
	
	@ManyToOne
	@JoinColumn(name = "dono_codigo")
	private Dono dono;
	
	@OneToOne(optional = false)
	@JoinColumn(name = "cod_destribuidora")
	private Destribuidora destribuidora;
	
	@ManyToMany
	@JoinTable(name = "tab_jogo_acessorio_CP3",
	joinColumns = @JoinColumn(name = "jogo_codigo"),
	inverseJoinColumns = @JoinColumn(name = "acessorio_codigo"))
	private Set<Acessorio> acessorios = new HashSet<>();
	
	public Jogo() {
	}
	
	

	public Jogo(Long codigo, String desenvolvedora, String nome, Integer anoLancamento, Integer nota, BigDecimal valor,
			TipoJogo tipoJogo, Calendar dataCadastro, String especificacoes, byte[] foto, boolean vendas, Dono dono,
			Destribuidora destribuidora, Set<Acessorio> acessorios) {
		super();
		this.codigo = codigo;
		this.desenvolvedora = desenvolvedora;
		this.nome = nome;
		this.anoLancamento = anoLancamento;
		this.nota = nota;
		this.valor = valor;
		this.tipoJogo = tipoJogo;
		this.dataCadastro = dataCadastro;
		this.especificacoes = especificacoes;
		this.foto = foto;
		this.vendas = vendas;
		this.dono = dono;
		this.destribuidora = destribuidora;
		this.acessorios = acessorios;
	}



	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getDesenvolvedora() {
		return desenvolvedora;
	}

	public void setDesenvolvedora(String desenvolvedora) {
		this.desenvolvedora = desenvolvedora;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getAnoLancamento() {
		return anoLancamento;
	}

	public void setAnoLancamento(Integer anoLancamento) {
		this.anoLancamento = anoLancamento;
	}

	public Integer getNota() {
		return nota;
	}

	public void setNota(Integer nota) {
		this.nota = nota;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public TipoJogo getTipoJogo() {
		return tipoJogo;
	}

	public void setTipoJogo(TipoJogo tipoJogo) {
		this.tipoJogo = tipoJogo;
	}

	public Calendar getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public String getEspecificacoes() {
		return especificacoes;
	}

	public void setEspecificacoes(String especificacoes) {
		this.especificacoes = especificacoes;
	}

	public byte[] getFoto() {
		return foto;
	}

	public void setFoto(byte[] foto) {
		this.foto = foto;
	}

	public boolean isVendas() {
		return vendas;
	}

	public void setVendas(boolean vendas) {
		this.vendas = vendas;
	}

	public Dono getDono() {
		return dono;
	}

	public void setDono(Dono dono) {
		this.dono = dono;
	}

	public Destribuidora getDestribuidora() {
		return destribuidora;
	}

	public void setDestribuidora(Destribuidora destribuidora) {
		this.destribuidora = destribuidora;
	}

	public Set<Acessorio> getAcessorios() {
		return acessorios;
	}

	public void setAcessorios(Set<Acessorio> acessorios) {
		this.acessorios = acessorios;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acessorios == null) ? 0 : acessorios.hashCode());
		result = prime * result + ((anoLancamento == null) ? 0 : anoLancamento.hashCode());
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((dataCadastro == null) ? 0 : dataCadastro.hashCode());
		result = prime * result + ((desenvolvedora == null) ? 0 : desenvolvedora.hashCode());
		result = prime * result + ((destribuidora == null) ? 0 : destribuidora.hashCode());
		result = prime * result + ((dono == null) ? 0 : dono.hashCode());
		result = prime * result + ((especificacoes == null) ? 0 : especificacoes.hashCode());
		result = prime * result + Arrays.hashCode(foto);
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((nota == null) ? 0 : nota.hashCode());
		result = prime * result + ((tipoJogo == null) ? 0 : tipoJogo.hashCode());
		result = prime * result + ((valor == null) ? 0 : valor.hashCode());
		result = prime * result + (vendas ? 1231 : 1237);
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Jogo other = (Jogo) obj;
		if (acessorios == null) {
			if (other.acessorios != null)
				return false;
		} else if (!acessorios.equals(other.acessorios))
			return false;
		if (anoLancamento == null) {
			if (other.anoLancamento != null)
				return false;
		} else if (!anoLancamento.equals(other.anoLancamento))
			return false;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (dataCadastro == null) {
			if (other.dataCadastro != null)
				return false;
		} else if (!dataCadastro.equals(other.dataCadastro))
			return false;
		if (desenvolvedora == null) {
			if (other.desenvolvedora != null)
				return false;
		} else if (!desenvolvedora.equals(other.desenvolvedora))
			return false;
		if (destribuidora == null) {
			if (other.destribuidora != null)
				return false;
		} else if (!destribuidora.equals(other.destribuidora))
			return false;
		if (dono == null) {
			if (other.dono != null)
				return false;
		} else if (!dono.equals(other.dono))
			return false;
		if (especificacoes == null) {
			if (other.especificacoes != null)
				return false;
		} else if (!especificacoes.equals(other.especificacoes))
			return false;
		if (!Arrays.equals(foto, other.foto))
			return false;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (nota == null) {
			if (other.nota != null)
				return false;
		} else if (!nota.equals(other.nota))
			return false;
		if (tipoJogo != other.tipoJogo)
			return false;
		if (valor == null) {
			if (other.valor != null)
				return false;
		} else if (!valor.equals(other.valor))
			return false;
		if (vendas != other.vendas)
			return false;
		return true;
	}

	

	
	
}