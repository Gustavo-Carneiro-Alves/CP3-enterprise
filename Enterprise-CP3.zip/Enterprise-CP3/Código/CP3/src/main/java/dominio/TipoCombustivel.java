package dominio;

public enum TipoCombustivel {

	ALCOOL,
	GASOLINA,
	DIESEL,
	BICOMBUSTIVEL
	
}
