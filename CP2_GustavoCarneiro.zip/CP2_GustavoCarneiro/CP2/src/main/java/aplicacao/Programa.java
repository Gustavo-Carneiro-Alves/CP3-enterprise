package aplicacao;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import dominio.TipoJogo;
import dominio.Jogo;
import dominio.JogoId;

public class Programa {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("loja-veiculos");
		EntityManager em = emf.createEntityManager();

		///*
		em.getTransaction().begin(); // h� a necessidade de se fazer uma transa��o ao inserir algo no bd		
		
		
		
		///*
		// parte iii - Usado data e CLOB
		StringBuilder especificacoes = new StringBuilder();
		especificacoes.append("Jogo em excelente estado.\n");
		especificacoes.append("Vers�o f�sica, sem mapa.\n");
		especificacoes.append("Primeiro dono, com embalagem lacrada ");
		especificacoes.append("e todas as normas de qualidade cumpridas.\n");
		especificacoes.append("N�o aceita reembolso.");
		
		Jogo jogo = new Jogo();
		jogo.setCodigo(new JogoId("US", "0001"));
		jogo.setDesenvolvedora("CD");
		jogo.setNome("Steampunk 1650");
		jogo.setAnoLancamento(2077);
		jogo.setNota(99);
		jogo.setValor(new BigDecimal(200));
		jogo.setTipoJogo(TipoJogo.FPS);
		jogo.setEspecificacoes(especificacoes.toString());
		jogo.setDataCadastro(Calendar.getInstance());
		
		em.persist(jogo);
		//*/// parte iii continua abaixo

		
			
		em.getTransaction().commit();
		
				
		///*
		// parte iii - Usado data e CLOB (continua��o)
		em.detach(jogo);
		Jogo jogo2 = em.find(Jogo.class, jogo.getCodigo());
		System.out.println("Ve�culo: " + jogo2.getCodigo());
		System.out.println("Ve�culo: " + jogo2.getNome());
		System.out.println("-------");
		System.out.println(jogo2.getEspecificacoes());
		//*/		
		
		
		/* Remover
		
		em.getTransaction().begin();
		Jogo jogo3 = em.find(Jogo.class, jogo.getCodigo());
		em.remove(jogo3);
		em.getTransaction().commit();
		
		*/
		
		/* Pesquisar todos
		
		Query query = em.createQuery("select v from Jogo v");
		
		List<Jogo> jogos = query.getResultList();
		for (Jogo jogo4 : jogos) {
			System.out.println(jogo4.getCodigo() + " - " 
					+ jogo4.getDesenvolvedora() + ", " 
					+ jogo4.getNome() + ", ano " 
					+ jogo4.getAnoLancamento() + " / nota: " 
					+ jogo4.getNota() + " por " 
					+ "R$"+ jogo4.getValor());
		}
		
		 */
		
		/* Pesquisar pela identifica��o
		
		JogoId codigo = new JogoId("US", "0001");
		Jogo jogo5 = em.find(Jogo.class, codigo);
		System.out.println("");
		System.out.println("Pesquisa 2");
		System.out.println("Regiao: " + jogo5.getCodigo().getRegiao());
		System.out.println("Numeracao: " + jogo5.getCodigo().getNumeracao());
		System.out.println("Desenvolvedora: " + jogo5.getDesenvolvedora());
		System.out.println("Nome: " + jogo5.getNome());
		
		*/
		
		/* Atualizar
		
		em.getTransaction().begin();
		
		Jogo jogo6 = em.find(Jogo.class, jogo.getCodigo());
		
		System.out.println("");
		System.out.println("Atualizando");
		System.out.println("Valor atual: " + jogo6.getValor());
		jogo6.setValor(jogo6.getValor().add(new BigDecimal(50)));
		System.out.println("Novo valor: " + jogo6.getValor());

		em.getTransaction().commit();
		
		*/

		System.out.println("pronto!");
		em.close(); // fechando...
		emf.close();

	}

}
