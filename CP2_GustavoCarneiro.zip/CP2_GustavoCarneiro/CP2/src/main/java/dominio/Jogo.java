package dominio;


import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "tab_jogo_teste")
public class Jogo {
	@EmbeddedId	
	private JogoId codigo;

	//@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	//private Long codigo;
	
	@Column(length = 60, nullable = false)
	private String desenvolvedora;
	
	@Column(length = 60, nullable = false)
	private String nome;
	
	@Column(name = "ano_Lancamento", nullable = false)
	private Integer anoLancamento;
	
	@Column(name = "nota", nullable = false)
	private Integer nota;
	
	@Column(precision = 10, scale = 2, nullable = true)
	private BigDecimal valor;
	
	@Column(name = "tipo_jogo", nullable = false)
	@Enumerated(EnumType.STRING) // EnumType.ORDINAL (insere n�mero ao inv�s da string)
	private TipoJogo tipoJogo;
	
	@Temporal(TemporalType.DATE)
    @Column(name = "data_cadastro", nullable = true)
    private Calendar dataCadastro;
	
	
	@Lob
	private String especificacoes;
	@Lob
	private byte[] foto;
	
	@Transient
	private boolean vendas;
	
	
	public Jogo() {
	}


	public Jogo(JogoId codigo, String desenvolvedora, String nome, Integer anoLancamento, Integer nota,
			BigDecimal valor, TipoJogo tipoJogo, Calendar dataCadastro, String especificacoes, byte[] foto,
			boolean vendas) {
		super();
		this.codigo = codigo;
		this.desenvolvedora = desenvolvedora;
		this.nome = nome;
		this.anoLancamento = anoLancamento;
		this.nota = nota;
		this.valor = valor;
		this.tipoJogo = tipoJogo;
		this.dataCadastro = dataCadastro;
		this.especificacoes = especificacoes;
		this.foto = foto;
		this.vendas = vendas;
	}


	public JogoId getCodigo() {
		return codigo;
	}


	public void setCodigo(JogoId codigo) {
		this.codigo = codigo;
	}


	public String getDesenvolvedora() {
		return desenvolvedora;
	}


	public void setDesenvolvedora(String desenvolvedora) {
		this.desenvolvedora = desenvolvedora;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public Integer getAnoLancamento() {
		return anoLancamento;
	}


	public void setAnoLancamento(Integer anoLancamento) {
		this.anoLancamento = anoLancamento;
	}


	public Integer getNota() {
		return nota;
	}


	public void setNota(Integer nota) {
		this.nota = nota;
	}


	public BigDecimal getValor() {
		return valor;
	}


	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}


	public TipoJogo getTipoJogo() {
		return tipoJogo;
	}


	public void setTipoJogo(TipoJogo tipoJogo) {
		this.tipoJogo = tipoJogo;
	}


	public Calendar getDataCadastro() {
		return dataCadastro;
	}


	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}


	public String getEspecificacoes() {
		return especificacoes;
	}


	public void setEspecificacoes(String especificacoes) {
		this.especificacoes = especificacoes;
	}


	public byte[] getFoto() {
		return foto;
	}


	public void setFoto(byte[] foto) {
		this.foto = foto;
	}


	public boolean isVendas() {
		return vendas;
	}


	public void setVendas(boolean vendas) {
		this.vendas = vendas;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(foto);
		result = prime * result + Objects.hash(anoLancamento, codigo, dataCadastro, desenvolvedora, especificacoes,
				nome, nota, tipoJogo, valor, vendas);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Jogo other = (Jogo) obj;
		return Objects.equals(anoLancamento, other.anoLancamento) && Objects.equals(codigo, other.codigo)
				&& Objects.equals(dataCadastro, other.dataCadastro)
				&& Objects.equals(desenvolvedora, other.desenvolvedora)
				&& Objects.equals(especificacoes, other.especificacoes) && Arrays.equals(foto, other.foto)
				&& Objects.equals(nome, other.nome) && Objects.equals(nota, other.nota) && tipoJogo == other.tipoJogo
				&& Objects.equals(valor, other.valor) && vendas == other.vendas;
	}


	
	
}