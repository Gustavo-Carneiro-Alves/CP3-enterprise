package dominio;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;

@Embeddable // embutida
public class JogoId implements Serializable {
	private static final long serialVersionUID = 1L;

	private String regiao;
	private String numeracao;

	public JogoId() {
	}

	public JogoId(String regiao, String numeracao) {
		super();
		this.regiao = regiao;
		this.numeracao = numeracao;
	}

	public String getRegiao() {
		return regiao;
	}

	public void setRegiao(String regiao) {
		this.regiao = regiao;
	}

	public String getNumeracao() {
		return numeracao;
	}

	public void setNumeracao(String numeracao) {
		this.numeracao = numeracao;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((numeracao == null) ? 0 : numeracao.hashCode());
		result = prime * result + ((regiao == null) ? 0 : regiao.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		JogoId other = (JogoId) obj;
		if (numeracao == null) {
			if (other.numeracao != null)
				return false;
		} else if (!numeracao.equals(other.numeracao))
			return false;
		if (regiao == null) {
			if (other.regiao != null)
				return false;
		} else if (!regiao.equals(other.regiao))
			return false;
		return true;
	}

	
}
