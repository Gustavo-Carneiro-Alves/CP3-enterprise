package dominio;

public enum TipoJogo {

	RPG,
	ACAO,
	ENIGMA,
	FPS,
	TPS,
	MOBA
	
}
