drop table tab_veiculo;

insert into tab_veiculo (fabricante, modelo, ano_fabricacao, ano_modelo, valor)
values ('Fiat', 'Toro', 2020, 2020, 107000);
insert into tab_veiculo (fabricante, modelo, ano_fabricacao, ano_modelo, valor)
values ('Ford', 'Fiesta', 2019, 2019, 42000);
insert into tab_veiculo (fabricante, modelo, ano_fabricacao, ano_modelo, valor)
values ('VW', 'Gol', 2019, 2020, 35000);

commit;
